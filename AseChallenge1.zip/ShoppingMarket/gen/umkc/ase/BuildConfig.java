/** Automatically generated file. DO NOT MODIFY */
package umkc.ase;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}